# Trip Visuals — Atualização da Loja

Olá! Tua loja recebeu uma atualização grande. Aqui vai um resumo rápido do que mudou e por quê.

---

## O que mudou pra teus clientes

### 1. Abertura cinematográfica
Quando alguém acessa o catálogo pela primeira vez, vê uma tela de boas-vindas com o nome **TRIP VISUALS** brilhando, um lembrete de "2 a 5 dias úteis · BR · P-XG" e o spinner de carregamento. Dura uns 2 segundos e some sozinho. Se a pessoa já visitou antes (na mesma aba), pula direto pro catálogo. Toque na tela também faz pular.

**Por quê:** banda tee é um produto de identidade, não de utilidade. Esse momento ajuda a fixar a marca e dá a sensação de "loja real, com personalidade", não de marketplace genérico.

### 2. Modal de produto detalhado
Antes: clicar num produto abria o WhatsApp na hora. Agora: abre uma janela bonita com a foto grande, nome, cor, preço, e um botão verde "Adquirir via WhatsApp".

**Por quê:** clientes querem olhar o design de perto antes de mandar mensagem. Reduz cliques acidentais no WhatsApp e aumenta as chances de a conversa ser séria.

### 3. Confirmação visual após mandar mensagem
Quando o cliente clica em "Adquirir via WhatsApp", a janela vira uma tela de confirmação com:
- Um check verde animado
- "Mensagem preparada!"
- Uma timeline mostrando: **Item escolhido ✓ → Aguardando confirmação → Em confecção → Enviado**
- Botão "Continuar navegando"

**Por quê:** antes, o cliente clicava e ficava sem feedback. Agora ele sabe que a mensagem foi enviada, sabe o que esperar a seguir, e fica confortável pra continuar olhando outras peças.

### 4. Botão de informações (FAQ)
Tem um ícone de "i" no canto superior do catálogo. Clicar abre um modal com:
- Prazo (2 a 5 dias úteis)
- Frete (todo Brasil)
- Tamanhos (P ao XG)
- Tabela completa de preços por tipo (camiseta MC, MM, regata, babylook, moletom careca, canguru)

**Por quê:** clientes têm essas dúvidas antes de mandar mensagem. Responder no FAQ economiza teu tempo no WhatsApp.

---

## O que mudou no teu painel

### Cores dos produtos — 28 opções
O campo de cor agora abre uma listinha com 28 cores prontas (Preta, Off-White, Vinho, Azul Marinho, Verde Musgo, etc.). Tu podes escolher ou digitar uma cor nova quando quiser. A cor digitada salva no sistema sem precisar mexer em código.

### Nome dos produtos mais limpo
Quando tu sobes uma foto chamada `alice-in-chains-30.jpeg`, o sistema agora cria o produto como **CAMISETA ALICE IN CHAINS PRETA** (sem o número). Antes mostrava "ALICE IN CHAINS 30" e ficava feio pro cliente. O número era só pra organizar tuas fotos.

### Botão "Ver ao vivo" na configuração da landing
Quando tu mexer na landing page, tem um botão "Ver ao vivo ↗" que abre uma aba nova com a versão real, sem precisar salvar.

---

## Como funciona o novo fluxo de compra (do começo ao fim)

1. **Cliente entra no catálogo** → vê a abertura por 2 segundos, depois o grid de produtos
2. **Bate o olho em algo que gostou** → clica na peça
3. **Modal abre** com a foto grande, nome, cor, preço
4. **Clica em "Adquirir via WhatsApp"** → WhatsApp abre em nova aba com a mensagem pronta:
   > Olá, equipe Trip Visuals! 🛸
   > Vim pelo catálogo e tenho interesse neste item:
   > Item: CAMISETA NIRVANA PRETA
   > Valor base: R$ 99,90
   > Poderia me ajudar com tamanhos disponíveis, opções de modelo e cálculo do frete para o meu CEP?
5. **No catálogo** → vê a tela de confirmação com a timeline
6. **Você responde no WhatsApp** → fecha a venda como faz hoje
7. **Cliente pode continuar navegando** ou fechar a aba

A mensagem fala "valor base" porque cada design pode virar várias peças (camiseta MC, MM, regata, etc.). Quem decide o tipo final é a conversa no WhatsApp.

---

## O que NÃO mudou (e por que isso é bom)

- Tu continua subindo produtos do mesmo jeito
- O WhatsApp continua sendo o canal de venda
- Os preços, formas de pagamento e frete são definidos por ti, peça por peça
- Tu tem controle total de qual cliente vira pedido

O sistema não decide nada por ti. Ele só prepara o cliente pra conversar contigo já sabendo das informações básicas.

---

## O que vem a seguir (quando tu quiser)

Coisas que dá pra fazer no futuro, mas não são pressa:

- **Categorias por gênero** (Rock, Metal, Grunge, etc.) com filtros no catálogo
- **Paginação** (quando passar de 300+ produtos)
- **Lista de interesse** — cliente pode juntar várias peças e mandar tudo numa mensagem só
- **Picker visual de cores** com as 28 cores em quadradinhos coloridos
- **Botão de download do catálogo em ZIP** (já tem o botão "em breve" no canto do site)

Nenhuma dessas é urgente. O sistema atual já dá conta da operação real.

---

## Dúvidas?

Esse documento cobre o essencial. Qualquer coisa que aparecer no dia a dia, é só me mandar mensagem que a gente ajusta.

Boas vendas!

**— Rory · VOIDZONE**
